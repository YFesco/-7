﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <Windows.h>


using namespace std;

struct Node
{
    Node() : yes(-1), no(-1) {}
    string q;
    int yes;
    int no;
};

void saveTree(const vector<Node>& tree, const string& fileName)
{
    ofstream out(fileName.c_str());
    if (!out.is_open())
    {
        cout << "Error opening file for writing!" << endl;
        return;
    }

    for (size_t i = 0; i < tree.size(); i++)
    {
        out << tree[i].q << endl;
        out << tree[i].yes << endl;
        out << tree[i].no << endl;
    }

    out.close();
}

vector<Node> loadTree(const string& fileName)
{
    ifstream in(fileName.c_str());
    if (!in.is_open())
    {
        cout << "Error opening file for reading!" << endl;
        return vector<Node>();
    }

    vector<Node> tree;
    string line;
    while (getline(in, line))
    {
        Node node;
        node.q = line;
        getline(in, line);
        node.yes = stoi(line);
        getline(in, line);
        node.no = stoi(line);
        tree.push_back(node);
    }

    in.close();
    return tree;
}

int main(int argc, char* argv[])
{
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    string fileName = "tree.txt";
    if (argc > 1)
    {
        fileName = argv[1];
    }

    vector<Node> tree;
    if (ifstream(fileName.c_str()))
    {
        tree = loadTree(fileName);
    }
    else
    {
        Node n;
        n.q = "торт";
        tree.push_back(n);
    }

    system("cls");
    cout << "Дисциплина:\tИнтеллектуальные системы и технологии\n"
        << "Группа:\t\tИС50-2-22\n"
        << "Студент:\tМолодовский И.С.\n"
        << "Пр. работа:\t№2 Моделирование простейшей сетевой ЭС на С++\n"
        << "Вариант:\t№16\n"
        << "-------------------------------------------------------------\n\n";

    while (true)
    {
        int i = 0;
        while (tree[i].yes != -1 && tree[i].no != -1)
        {
            cout << "Это " << tree[i].q << "? (1 - да, 0 - нет) ";
            int ans;
            cin >> ans;
            if (ans == 1)
                i = tree[i].yes;
            else
                i = tree[i].no;
        }

        cout << "Это " << tree[i].q << "? (1 - да, 0 - нет) ";
        int ans;
        cin >> ans;
        if (ans == 1)
        {
            cout << "Угадали!" << endl;
        }
        else
        {
            cout << "Кто это? ";
            string anim;
            cin >> anim;
            cout << "Чем " << tree[i].q << " отличается от " << anim << "? ";
            string diff;
            cin >> diff;
            Node yes = tree[i];
            Node no;
            no.q = anim;
            tree[i].yes = tree.size();
            tree.push_back(yes);
            tree[i].no = tree.size();
            tree.push_back(no);
            tree[i].q = diff;
        }

        cout << "Еще раз? (1 - да, 0 - нет) ";
        cin >> ans;
        if (ans == 0)
        {
            saveTree(tree, fileName);
            break;
        }
        else
        {
            cout << endl
                << "-------------------------------------------------" << endl;
        }
    }

    return 0;
}
