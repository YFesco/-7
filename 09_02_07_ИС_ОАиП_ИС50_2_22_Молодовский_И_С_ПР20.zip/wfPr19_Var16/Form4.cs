﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfPr20_Var16
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "cakeDataSet.Postavshik". При необходимости она может быть перемещена или удалена.
            this.postavshikTableAdapter.Fill(this.cakeDataSet.Postavshik);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "cakeDataSet.Prodazha_Torta". При необходимости она может быть перемещена или удалена.
            this.prodazha_TortaTableAdapter.Fill(this.cakeDataSet.Prodazha_Torta);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "cakeDataSet.Vid_Torta". При необходимости она может быть перемещена или удалена.
            this.vid_TortaTableAdapter.Fill(this.cakeDataSet.Vid_Torta);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            vidTortaBindingSource.EndEdit();
            vid_TortaTableAdapter.Update(cakeDataSet);
        }

        private void btnSave2_Click(object sender, EventArgs e)
        {
            prodazhaTortaBindingSource.EndEdit();
            prodazha_TortaTableAdapter.Update(cakeDataSet);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PrintDocument printDocument = new PrintDocument();
            printDocument.PrintPage += new PrintPageEventHandler(PrintPage);
            PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog();
            printPreviewDialog.Document = printDocument;
            printPreviewDialog.ShowDialog();
        }
        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            DataGridView dataGridView = null;
            if (dataGridView1.Visible)
            {
                dataGridView = dataGridView1;
            }
            else if (dataGridView2.Visible)
            {
                dataGridView = dataGridView2;
            }
            Bitmap bitmap = new Bitmap(dataGridView.Width, dataGridView.Height);
            dataGridView1.DrawToBitmap(bitmap, new Rectangle(1, 1, dataGridView.Width, dataGridView.Height));
            e.Graphics.DrawImage(bitmap, e.PageBounds);
        }

    }
}
