﻿
namespace wfPr20_Var16
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cakeDataSet = new wfPr20_Var16.CakeDataSet();
            this.vidTortaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vid_TortaTableAdapter = new wfPr20_Var16.CakeDataSetTableAdapters.Vid_TortaTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.prodazhaTortaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.prodazha_TortaTableAdapter = new wfPr20_Var16.CakeDataSetTableAdapters.Prodazha_TortaTableAdapter();
            this.postavshikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.postavshikTableAdapter = new wfPr20_Var16.CakeDataSetTableAdapters.PostavshikTableAdapter();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSave2 = new System.Windows.Forms.Button();
            this.vidTortaProdazhaTortaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idvidtortaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idPostavshikProductsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.idprodazhyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vidTortaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceTortaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.klassTortaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cakeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vidTortaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaTortaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postavshikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vidTortaProdazhaTortaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idvidtortaDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.idPostavshikProductsDataGridViewTextBoxColumn,
            this.Column1});
            this.dataGridView1.DataSource = this.vidTortaBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 61);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(443, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // cakeDataSet
            // 
            this.cakeDataSet.DataSetName = "CakeDataSet";
            this.cakeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vidTortaBindingSource
            // 
            this.vidTortaBindingSource.DataMember = "Vid Torta";
            this.vidTortaBindingSource.DataSource = this.cakeDataSet;
            // 
            // vid_TortaTableAdapter
            // 
            this.vid_TortaTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idprodazhyDataGridViewTextBoxColumn,
            this.vidTortaDataGridViewTextBoxColumn,
            this.priceTortaDataGridViewTextBoxColumn,
            this.klassTortaDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.vidTortaProdazhaTortaBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(12, 260);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(443, 150);
            this.dataGridView2.TabIndex = 1;
            // 
            // prodazhaTortaBindingSource
            // 
            this.prodazhaTortaBindingSource.DataMember = "Prodazha Torta";
            this.prodazhaTortaBindingSource.DataSource = this.cakeDataSet;
            // 
            // prodazha_TortaTableAdapter
            // 
            this.prodazha_TortaTableAdapter.ClearBeforeFill = true;
            // 
            // postavshikBindingSource
            // 
            this.postavshikBindingSource.DataMember = "Postavshik";
            this.postavshikBindingSource.DataSource = this.cakeDataSet;
            // 
            // postavshikTableAdapter
            // 
            this.postavshikTableAdapter.ClearBeforeFill = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(473, 106);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSave2
            // 
            this.btnSave2.Location = new System.Drawing.Point(473, 317);
            this.btnSave2.Name = "btnSave2";
            this.btnSave2.Size = new System.Drawing.Size(75, 23);
            this.btnSave2.TabIndex = 3;
            this.btnSave2.Text = "Сохранить";
            this.btnSave2.UseVisualStyleBackColor = true;
            this.btnSave2.Click += new System.EventHandler(this.btnSave2_Click);
            // 
            // vidTortaProdazhaTortaBindingSource
            // 
            this.vidTortaProdazhaTortaBindingSource.DataMember = "Vid TortaProdazha Torta";
            this.vidTortaProdazhaTortaBindingSource.DataSource = this.vidTortaBindingSource;
            // 
            // idvidtortaDataGridViewTextBoxColumn
            // 
            this.idvidtortaDataGridViewTextBoxColumn.DataPropertyName = "id_vidtorta";
            this.idvidtortaDataGridViewTextBoxColumn.HeaderText = "Код вида товара";
            this.idvidtortaDataGridViewTextBoxColumn.Name = "idvidtortaDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Название";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Цена";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // idPostavshikProductsDataGridViewTextBoxColumn
            // 
            this.idPostavshikProductsDataGridViewTextBoxColumn.DataPropertyName = "id_PostavshikProducts";
            this.idPostavshikProductsDataGridViewTextBoxColumn.HeaderText = "id_PostavshikProducts";
            this.idPostavshikProductsDataGridViewTextBoxColumn.Name = "idPostavshikProductsDataGridViewTextBoxColumn";
            this.idPostavshikProductsDataGridViewTextBoxColumn.Visible = false;
            // 
            // Column1
            // 
            this.Column1.DataSource = this.postavshikBindingSource;
            this.Column1.DisplayMember = "Products";
            this.Column1.HeaderText = "Продукт от поставщика";
            this.Column1.Name = "Column1";
            this.Column1.ValueMember = "id_PostavshikProducts";
            // 
            // idprodazhyDataGridViewTextBoxColumn
            // 
            this.idprodazhyDataGridViewTextBoxColumn.DataPropertyName = "id_prodazhy";
            this.idprodazhyDataGridViewTextBoxColumn.HeaderText = "Код продажи";
            this.idprodazhyDataGridViewTextBoxColumn.Name = "idprodazhyDataGridViewTextBoxColumn";
            // 
            // vidTortaDataGridViewTextBoxColumn
            // 
            this.vidTortaDataGridViewTextBoxColumn.DataPropertyName = "Vid Torta";
            this.vidTortaDataGridViewTextBoxColumn.HeaderText = "Вид торта";
            this.vidTortaDataGridViewTextBoxColumn.Name = "vidTortaDataGridViewTextBoxColumn";
            // 
            // priceTortaDataGridViewTextBoxColumn
            // 
            this.priceTortaDataGridViewTextBoxColumn.DataPropertyName = "Price Torta";
            this.priceTortaDataGridViewTextBoxColumn.HeaderText = "Цена торта";
            this.priceTortaDataGridViewTextBoxColumn.Name = "priceTortaDataGridViewTextBoxColumn";
            // 
            // klassTortaDataGridViewTextBoxColumn
            // 
            this.klassTortaDataGridViewTextBoxColumn.DataPropertyName = "Klass Torta";
            this.klassTortaDataGridViewTextBoxColumn.HeaderText = "Класс торта";
            this.klassTortaDataGridViewTextBoxColumn.Name = "klassTortaDataGridViewTextBoxColumn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Вид товара";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 227);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Продажа торта";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(473, 169);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Печать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSave2);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form4";
            this.Text = "База данных \"Торт\"";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cakeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vidTortaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodazhaTortaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postavshikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vidTortaProdazhaTortaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private CakeDataSet cakeDataSet;
        private System.Windows.Forms.BindingSource vidTortaBindingSource;
        private CakeDataSetTableAdapters.Vid_TortaTableAdapter vid_TortaTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource prodazhaTortaBindingSource;
        private CakeDataSetTableAdapters.Prodazha_TortaTableAdapter prodazha_TortaTableAdapter;
        private System.Windows.Forms.BindingSource postavshikBindingSource;
        private CakeDataSetTableAdapters.PostavshikTableAdapter postavshikTableAdapter;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSave2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idvidtortaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPostavshikProductsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idprodazhyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vidTortaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceTortaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn klassTortaDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource vidTortaProdazhaTortaBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}